package net.coderbot.iris;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.coderbot.iris.gl.framebuffer.GlFramebuffer;
import net.coderbot.iris.gl.uniform.Matrix4fExt;
import net.coderbot.iris.layer.GbufferProgram;
import net.coderbot.iris.layer.GbufferPrograms;
import net.coderbot.iris.math.CanvasFrustum;
import net.coderbot.iris.math.FastFrustum;
import net.coderbot.iris.math.Matrices;
import net.coderbot.iris.mixin.AccessorWorldRenderer;
import net.coderbot.iris.rendertarget.RenderTargets;
import net.coderbot.iris.uniforms.CapturedRenderingState;
import net.coderbot.iris.uniforms.CelestialUniforms;
import net.coderbot.iris.uniforms.SystemTimeUniforms;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.client.util.math.Vector4f;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Matrix4f;
import org.lwjgl.opengl.*;

public class ShadowTextureRenderer {
	private static boolean RENDERING_SHADOW_TEX = false;
	private static final int SKYLIGHT_VECTOR = 4 * 11;
	private static final SystemTimeUniforms.FrameCounter COUNTER = new SystemTimeUniforms.FrameCounter();
	public static final Matrix4f shadowViewMatrix = new Matrix4f();
	public static final Matrix4fExt shadowViewMatrixExt = (Matrix4fExt) (Object) shadowViewMatrix;
	public static Matrix4f shadowProjMatrix = new Matrix4f();
	public static final Matrix4fExt shadowProjMatrixExt = (Matrix4fExt) (Object) shadowProjMatrix;
	private static float lastDx, lastDy;
	public static Matrix4f shadowView2;
	private static final Vector3f vec = new Vector3f();
	private static final Vector4f testVec = new Vector4f();
	public static final Vector3f skyLightVector = new Vector3f();
	private static final FastFrustum EMPTY_FRUSTUM = new FastFrustum() {
		@Override
		public boolean isVisible(Box box) {
			return true;
		}
	};

	public static int SHADOW_TEX_WIDTH = 4096;

	public static void render(Camera camera, float tickDelta) {
		shadowProjMatrix = MinecraftClient.getInstance().gameRenderer.getBasicProjectionMatrix(camera, tickDelta, true);
		if(RENDERING_SHADOW_TEX) return;
		RENDERING_SHADOW_TEX = true;

		MatrixStack matrices = new MatrixStack();
		GlFramebuffer shadows = new GlFramebuffer();
		MinecraftClient client = MinecraftClient.getInstance();
		ClientWorld world = client.world;
		WorldRenderer worldRenderer = client.worldRenderer;
		GameRenderer gameRenderer = client.gameRenderer;
		RenderTargets renderTargets = Iris.getPipeline().getRenderTargets();
		int shadowTex = renderTargets.getShadowTexture().getTextureId();
		int shadowNoTranslucents = renderTargets.getShadowTextureNoTranslucents().getTextureId();

		GL11.glEnable(GL11.GL_DEPTH_TEST);
		shadows.addDepthAttachment(shadowTex);
		//shadows.addDepthAttachment(shadowNoTranslucents);
		GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
		shadows.bind();
		ARBFramebufferObject.glFramebufferTexture2D(ARBFramebufferObject.GL_FRAMEBUFFER, ARBFramebufferObject.GL_DEPTH_ATTACHMENT, ARBInternalformatQuery2.GL_TEXTURE_2D, shadowTex, 0);
		GL32.glReadBuffer(GL11.GL_NONE);
		GL32.glDrawBuffer(GL11.GL_NONE);
		GbufferPrograms.push(GbufferProgram.SHADOW);
		GL32.glDepthMask(true);


		//gameRenderer.loadProjectionMatrix(projection);
		//CapturedRenderingState.INSTANCE.setShadowProjection(projection);
		//GL11.glPushMatrix();
		//RenderSystem.pushMatrix();
		GL32.glMatrixMode(GL11.GL_PROJECTION);
		Matrix4f projection = Matrix4f.projectionMatrix(1, 1, 0, 0);//Matrices.ortho(-160, 160, -160, 160, 0.05f, 256);
		final int radius = Math.round(EMPTY_FRUSTUM.circumRadius());
		//Matrix4fExt projectionnew = CapturedRenderingState.INSTANCE.getGbufferProjection();

		//projection.transpose();
		//float[] prev = new float[16];
		//GL32.glGetFloatv(GL11.GL_PROJECTION_MATRIX, prev);
		shadowViewMatrix.loadIdentity();
		shadowViewMatrix.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(-90));
		shadowViewMatrix.multiply(Vector3f.POSITIVE_Z.getDegreesQuaternion(0));
		shadowViewMatrix.multiply(Vector3f.POSITIVE_X.getDegreesQuaternion(CelestialUniforms.getShadowAngle()));
		testVec.set(0, 1, 0, 0);
		testVec.transform(shadowViewMatrix);
		skyLightVector.set(testVec.getX(), testVec.getY(), testVec.getZ());
		shadowViewMatrixExt.lookAt(
				skyLightVector.getX() * radius * 2, skyLightVector.getY() * radius * 2, skyLightVector.getZ() * radius * 2,
				0, 0, 0,
				0.0f, 0.0f, 1.0f);
		computeViewBounds(shadowViewMatrixExt, (float) MinecraftClient.getInstance().gameRenderer.getCamera().getPos().x, (float) MinecraftClient.getInstance().gameRenderer.getCamera().getPos().y, (float) MinecraftClient.getInstance().gameRenderer.getCamera().getPos().z);
		final double worldPerPixel = 2.0 * radius / 4096;
		float dx = lastDx + testVec.getX();
		float dy = lastDy + testVec.getY();
		dx = (float) (dx - Math.floor(dx / worldPerPixel) * worldPerPixel);
		dy = (float) (dy - Math.floor(dy / worldPerPixel) * worldPerPixel);

		// NaN values sometime crop up in edge cases, esp during initialization.
		// If we don't correct for them then the accumulated adjustment becomes Nan
		// and never recovers.
		if (Float.isNaN(dx)) {
			dx = 0f;
		}

		if (Float.isNaN(dy)) {
			dy = 0f;
		}
		float cx = (minViewX() + maxViewX()) * 0.5f;
		float cy = (minViewY() + maxViewY()) * 0.5f;
		float cz = (minViewZ() + maxViewZ()) * 0.5f;

		cx = (float) (Math.floor(cx / worldPerPixel) * worldPerPixel) - dx;
		cy = (float) (Math.floor(cy / worldPerPixel) * worldPerPixel) - dy;
		cz = (float) -(Math.floor(cz / worldPerPixel) * worldPerPixel);

		// We previously use actual geometry depth to give better precision on Z.
		// However, scenes are so variable that this causes problems for optimizing polygonOffset
		// Z axis inverted to match depth axis in OpenGL

		// Construct ortho matrix using bounding sphere/box computed above.
		// Should give us a consistent size each frame, which helps prevent shimmering.
		shadowProjMatrixExt.setOrtho(
				cx - radius, cx + radius,
				cy - radius, cy + radius,
				cz - radius, cz + radius);
		Matrix4f shadowProj2 = (Matrix4f) (Object) shadowProjMatrixExt;
		//GL32.glMultMatrixf(Matrices.of(projection));
		//GL32.glOrtho(-160, 160, -160, 160, 0.05f, 256);
		GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL30.GL_TEXTURE_2D, shadowNoTranslucents, 0);
		//matrices.push();
		//worldRenderer.render(matrices, client.getTickDelta(), world.getTime(), false, gameRenderer.getCamera(), gameRenderer, gameRenderer.getLightmapTextureManager(), matrices.peek().getModel());
		((AccessorWorldRenderer)worldRenderer).doSetupTerrain(camera, ((AccessorWorldRenderer)worldRenderer).getCapturedFrustum(), true, 0, false);
		GlStateManager.bindTexture(shadowTex);
		GL20C.glActiveTexture(4);
		GL20C.glCopyTexImage2D(GL20C.GL_TEXTURE_2D, 0, GL20C.GL_DEPTH_COMPONENT, 0, 0, ShadowTextureRenderer.SHADOW_TEX_WIDTH, ShadowTextureRenderer.SHADOW_TEX_WIDTH, 0);
		//GL11.glPopMatrix();
		//GlStateManager.bindTexture(shadowNoTranslucents);
		//GL20C.glCopyTexImage2D(GL20C.GL_TEXTURE_2D, 0, GL20C.GL_DEPTH_COMPONENT, 0, 0, ShadowTextureRenderer.SHADOW_TEX_WIDTH, ShadowTextureRenderer.SHADOW_TEX_WIDTH, 0);

		CapturedRenderingState.INSTANCE.setShadowProjection(shadowProj2);
		Iris.logger.warn("shadowproj" + shadowProj2);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GbufferPrograms.pop(GbufferProgram.SHADOW);
		shadows.destroy();

		//GL32.glLoadMatrixf(prev);

		RENDERING_SHADOW_TEX = false;
		//gameRenderer.loadProjectionMatrix(gameRenderer.getBasicProjectionMatrix(camera, tickDelta, true));
	}
	private static int minX;
	private static int minY;
	private static int minZ;
	private static int maxX;
	private static int maxY;
	private static int maxZ;

	private static float minViewX;
	private static float minViewY;
	private static float minViewZ;
	private static float maxViewX;
	private static float maxViewY;
	private static float maxViewZ;
	static int stuff = 0;
	public static void computeViewBounds(Matrix4fExt viewMatrix, float cameraX, float cameraY, float cameraZ) {
		vec.set(minX - cameraX, minY - cameraY, minZ - cameraZ);
		viewMatrix.fastTransform(vec);

		minViewX = vec.getX();
		maxViewX = vec.getX();
		minViewY = vec.getY();
		maxViewY = vec.getY();
		minViewZ = vec.getZ();
		maxViewZ = vec.getZ();

		vec.set(minX - cameraX, minY - cameraY, maxZ - cameraZ);
		viewMatrix.fastTransform(vec);
		expandViewBounds();

		vec.set(minX - cameraX, maxY - cameraY, minZ - cameraZ);
		viewMatrix.fastTransform(vec);
		expandViewBounds();

		vec.set(minX - cameraX, maxY - cameraY, maxZ - cameraZ);
		viewMatrix.fastTransform(vec);
		expandViewBounds();

		vec.set(maxX - cameraX, minY - cameraY, minZ - cameraZ);
		viewMatrix.fastTransform(vec);
		expandViewBounds();

		vec.set(maxX - cameraX, minY - cameraY, maxZ - cameraZ);
		viewMatrix.fastTransform(vec);
		expandViewBounds();

		vec.set(maxX - cameraX, maxY - cameraY, minZ - cameraZ);
		viewMatrix.fastTransform(vec);
		expandViewBounds();

		vec.set(maxX - cameraX, maxY - cameraY, maxZ - cameraZ);
		viewMatrix.fastTransform(vec);
		expandViewBounds();
	}
	private static void expandViewBounds() {
		final float x = vec.getX();

		if (x < minViewX) {
			minViewX = x;
		} else if (x > maxViewX) {
			maxViewX = x;
		}

		final float y = vec.getY();

		if (y < minViewY) {
			minViewY = y;
		} else if (y > maxViewY) {
			maxViewY = y;
		}

		final float z = vec.getZ();

		if (z < minViewZ) {
			minViewZ = z;
		} else if (z > maxViewZ) {
			maxViewZ = z;
		}
	}

	public static float minViewX() {
		return minViewX;
	}

	public static float minViewY() {
		return minViewY;
	}

	public static float minViewZ() {
		return minViewZ;
	}

	public static float maxViewX() {
		return maxViewX;
	}

	public static float maxViewY() {
		return maxViewY;
	}

	public static float maxViewZ() {
		return maxViewZ;
	}

	public int midX() {
		return (minX + maxX) >> 1;
	}

	public int midY() {
		return (minY + maxY) >> 1;
	}

	public int midZ() {
		return (minZ + maxZ) >> 1;
	}
	public static void imsRender(Camera camera, MatrixStack matrices, float tickDelta) {
		GlFramebuffer shadowframe = new GlFramebuffer();
		RenderTargets renderTargets = Iris.getPipeline().getRenderTargets();
		//Iris.getPipeline().beginWorldRender();
		Frustum frustum = new Frustum(new Matrix4f(), new Matrix4f()) {
			@Override
			public boolean isVisible(Box box) {
				return true;
			}
		};
		if(stuff == 0) {

			stuff = 1;
		}
		else
		{
			//Iris.logger.warn("pos" + CelestialUniforms.getShadowLightPosition());
			frustum.setPosition(camera.getPos().x, camera.getPos().y, camera.getPos().z + CelestialUniforms.getShadowLightPosition().getZ());
		}
		//camera.
		GlStateManager.disableCull();
		ClientWorld world = MinecraftClient.getInstance().world;
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		shadowframe.addDepthAttachment(renderTargets.getShadowTexture().getTextureId());
		//shadowframe.bindo();
		GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
		shadowframe.bind();
		//MinecraftClient.getInstance().options.setPerspective(Perspective.THIRD_PERSON_BACK);
		ARBFramebufferObject.glFramebufferTexture2D(ARBFramebufferObject.GL_FRAMEBUFFER, ARBFramebufferObject.GL_DEPTH_ATTACHMENT, ARBInternalformatQuery2.GL_TEXTURE_2D, renderTargets.getShadowTexture().getTextureId(), 0);
		GL32.glReadBuffer(GL11.GL_NONE);
		GL32.glDrawBuffer(GL11.GL_NONE);
		matrices.push();
		GbufferPrograms.push(GbufferProgram.SHADOW);
		matrices.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(-90.0F));
		matrices.multiply(Vector3f.POSITIVE_X.getDegreesQuaternion(world.getSkyAngle(tickDelta) * 360.0F));
		matrices.translate(0, 100, 0);
		CapturedRenderingState.INSTANCE.setShadowModelView(matrices.peek().getModel());
		matrices.pop();
		//GL31.glActiveTexture(4);
		//GL31.glCopyTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_DEPTH_COMPONENT, 0, 0, 4096, 4096, 0);
		//GL31.glActiveTexture(0);
		//ShadowProject.setupSecondCamera();

		//Matrix4f projectshadow = gameRenderer.getBasicProjectionMatrix(camera2, tickDelta, true);
		GL32.glDepthMask(true);


		//GL32.glViewport(0, 0, 4096, 4096);

		GL11.glPushMatrix();
		GL32.glMatrixMode(GL11.GL_PROJECTION);
		GL32.glLoadIdentity();
		GL32.glOrtho(-160, 160, -160, 160, 0.05D, 256.0D);
		//CapturedRenderingState.INSTANCE.setShadowProjection(Matrix4f.projectionMatrix(1, 1, 0, 0));
		WorldRenderer worldRenderer = MinecraftClient.getInstance().worldRenderer;
		MinecraftClient.getInstance().chunkCullingEnabled = false;

		((AccessorWorldRenderer) worldRenderer).doSetupTerrain(camera, frustum, false, 0, MinecraftClient.getInstance().player.isSpectator());
		GlStateManager.bindTexture(renderTargets.getShadowTexture().getTextureId());
		GL20C.glCopyTexImage2D(GL20C.GL_TEXTURE_2D, 0, GL20C.GL_DEPTH_COMPONENT, 0, 0, 4096, 4096, 0);
		GL11.glPopMatrix();

		//renderer.renderWorld(tickDelta, 1, matrices);


		//worldRenderer.renderlayer



		//GL32.glOrtho((double)(-halfShadowMapPlane), (double)halfShadowMapPlane, (double)(-halfShadowMapPlane), (double)halfShadowMapPlane, 1D, 1.0D);
		//GL32.glOrtho(-1, 1, -1, 1, -1, 1);
		//MinecraftClient.getInstance().options.setPerspective(Perspective.FIRST_PERSON);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GbufferPrograms.pop(GbufferProgram.SHADOW);
		//ShaderPipeline.baseline.bind();

		shadowframe.destroy();
	}
}
