package net.coderbot.iris.impl;

public interface Matrix4fAccess {
	void setMatrix(float[] m);

	float[] getValues();
}
