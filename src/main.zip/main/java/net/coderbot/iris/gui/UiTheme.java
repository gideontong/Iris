package net.coderbot.iris.gui;

public enum UiTheme {
    IRIS, VANILLA, SODIUM
}
