package net.coderbot.iris.gui;

public interface TransparentBackgroundScreen {
    boolean renderHud();
}
