package net.coderbot.iris.gl.uniform;

@FunctionalInterface
public interface FloatSupplier {
	float getAsFloat();
}
