package net.coderbot.iris.gl.uniform;

public enum UniformUpdateFrequency {
	ONCE,
	PER_TICK,
	PER_FRAME
}
