package net.coderbot.iris.layer;

public interface MultiPhaseParametersExtension {
	void useProgram(GbufferProgram program);
}
