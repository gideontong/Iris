package net.coderbot.iris.layer;

public interface ProgramHolder {
	void program(GbufferProgram program);
}
